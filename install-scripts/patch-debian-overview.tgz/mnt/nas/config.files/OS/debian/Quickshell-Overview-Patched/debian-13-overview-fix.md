## The failure was a Qt type mismatch, not a Quickshell version issue.

- RectangularShadow in QtQuick.Effects is not available in your installed QtQuick.Effects plugin
   - (it exports MultiEffect, not RectangularShadow), so StyledRectangularShadow.qml couldn’t load.

### I fixed it by updating:

-  /home/username/.config/quickshell/overview/common/widgets/StyledRectangularShadow.qml

### Changes made:
-  Switched import from QtQuick.Effects to Qt5Compat.GraphicalEffects
