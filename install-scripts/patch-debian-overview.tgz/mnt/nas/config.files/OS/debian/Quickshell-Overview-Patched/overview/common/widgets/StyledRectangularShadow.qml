import QtQuick
import Qt5Compat.GraphicalEffects
import ".."

DropShadow {
    required property var target
    anchors.fill: target
    source: target
    radius: 0.9 * Appearance.sizes.elevationMargin
    samples: Math.max(3, Math.round(radius * 2) + 1)
    horizontalOffset: 0
    verticalOffset: 1
    transparentBorder: true
    color: Appearance.colors.colShadow
    cached: true
}
